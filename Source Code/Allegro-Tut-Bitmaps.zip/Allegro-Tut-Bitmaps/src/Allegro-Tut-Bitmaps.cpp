//Assets: Stuff you use in the game (e.g. sprites, sound, background image, text, tiles, etc.)
//Bitmap: A file extension that contains information on image. It's
//also a variable in Allegro 5 that holds image data.
//Bitmap file extension is .bmp
//Bitmap variable can also apply to .png or .jpeg

#include <iostream>
#include <allegro5/allegro.h>
#include <allegro5/allegro_primitives.h>

//Before we implement bitmap, first add the Allegro 5 library for image
#include <allegro5/allegro_image.h>

using namespace std;

int main() {


    al_init();
    //You need an addon to use the bitmap variable
    al_init_image_addon();

    al_init_primitives_addon();

    double FPS = 60.0;

    ALLEGRO_DISPLAY *window = al_create_display(500, 500);
    ALLEGRO_EVENT_QUEUE *q = al_create_event_queue();

    ALLEGRO_TIMER *timer = al_create_timer(1/FPS);

    //Declare Bitmap Variable and assign it to load bitmap files or any other image files
    ALLEGRO_BITMAP *image = al_load_bitmap("King Tut Logo.png");



    al_register_event_source(q, al_get_timer_event_source(timer));
    al_register_event_source(q, al_get_display_event_source(window));

    bool done = false;

    al_start_timer(timer);

    while (!done)
    {

    	ALLEGRO_EVENT e;
    	al_wait_for_event(q, &e);

    	if (e.type == ALLEGRO_EVENT_DISPLAY_CLOSE)
    	{
    		done = true;
    	}

    	if(e.type == ALLEGRO_EVENT_TIMER)
    	{
    		al_clear_to_color(al_map_rgb(255,0,0));


    		//Draw your image here
    		al_draw_bitmap(image, 0, 0, NULL);

    		al_flip_display();
    	}
    }

    al_destroy_display(window);
    al_destroy_event_queue(q);
    al_destroy_timer(timer);

    //Once you are done with the bitmap variable, release the memory
    al_destroy_bitmap(image);

    return 0;
}
