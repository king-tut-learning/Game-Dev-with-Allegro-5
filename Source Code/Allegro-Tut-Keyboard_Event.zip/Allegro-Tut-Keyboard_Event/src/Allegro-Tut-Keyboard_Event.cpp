#include <iostream>
#include <allegro5/allegro.h>
#include <allegro5/allegro_primitives.h>
using namespace std;

int main() {
    al_init();
    al_install_mouse();
    al_init_primitives_addon();
    ALLEGRO_DISPLAY *window = al_create_display(500, 500);
    ALLEGRO_EVENT_QUEUE *q = al_create_event_queue();
    al_register_event_source(q, al_get_mouse_event_source());
    bool done = false;

    while (!done)
    {
    	al_clear_to_color(al_map_rgb(255,0,0));
    	al_draw_filled_circle(100, 100, 50, al_map_rgb(0, 0, 0));
    	al_flip_display();

    	ALLEGRO_EVENT e;
    	al_wait_for_event(q, &e);

    	if(e.type == ALLEGRO_EVENT_MOUSE_BUTTON_DOWN)
    	{
    		if (e.mouse.button & 1)
    		{
    			done = true;
    		}

    	}


    }

    al_destroy_display(window);
    al_destroy_event_queue(q);
    return 0;
}
