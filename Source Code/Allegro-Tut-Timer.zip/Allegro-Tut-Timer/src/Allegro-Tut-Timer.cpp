#include <iostream>
#include <allegro5/allegro.h>
#include <allegro5/allegro_primitives.h>
using namespace std;

int main() {

	//Questions4U: How to make video games that benefits not only
	//the newer computer, but the older ones?
	//How do you render without waiting for an event to occur?
	//That's where timer comes into play
    al_init();
    al_init_primitives_addon();

    //step 1: declare a double variable and call it FPS
    double FPS = 60.0;

    ALLEGRO_DISPLAY *window = al_create_display(500, 500);
    ALLEGRO_EVENT_QUEUE *q = al_create_event_queue();

    //step 2: declare an ALLEGRO_TIMER pointer variable
    //and set it equal to 1/FPS
    ALLEGRO_TIMER *timer = al_create_timer(1/FPS);

    //step 3: register the timer as an event source
    al_register_event_source(q, al_get_timer_event_source(timer));

    al_register_event_source(q, al_get_display_event_source(window));
    bool done = false;

    //step 4: start the timer
    al_start_timer(timer);

    while (!done)
    {


    	ALLEGRO_EVENT e;
    	al_wait_for_event(q, &e);

    	if (e.type == ALLEGRO_EVENT_DISPLAY_CLOSE)
    	{
    		done = true;
    	}

    	//step 5: put in conditional statement for timer
    	if(e.type == ALLEGRO_EVENT_TIMER)
    	{
    		al_clear_to_color(al_map_rgb(255,0,0));
    		al_draw_filled_circle(100, 100, 50, al_map_rgb(0, 0, 0));
    		al_flip_display();
    	}
    }

    al_destroy_display(window);
    al_destroy_event_queue(q);
    al_destroy_timer(timer);
    return 0;
}
