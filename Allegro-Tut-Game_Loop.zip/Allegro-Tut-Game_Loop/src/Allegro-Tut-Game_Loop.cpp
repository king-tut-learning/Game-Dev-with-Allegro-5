#include <iostream>
#include <allegro5/allegro.h>
#include <allegro5/allegro_primitives.h>
using namespace std;

int main() {
    al_init();
    al_init_primitives_addon();
    ALLEGRO_DISPLAY *window = al_create_display(500, 500);
    bool done = false;

    while (!done)
    {
    	al_clear_to_color(al_map_rgb(255,0,0));
    	al_draw_filled_circle(100, 100, 50, al_map_rgb(0, 0, 0));
    	al_flip_display();
    }


    al_destroy_display(window);
    return 0;
}
