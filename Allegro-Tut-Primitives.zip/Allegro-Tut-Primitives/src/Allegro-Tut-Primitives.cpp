#include <iostream>
#include <allegro5/allegro.h>
#include <allegro5/allegro_primitives.h>
using namespace std;

int main() {

	//Primitives: A feature in Allegro 5 that allows you to draw points, lines, and shapes
    al_init();
    //You need this function to be able to draw points, lines, and shapes
    al_init_primitives_addon();

    double FPS = 60.0;

    ALLEGRO_DISPLAY *window = al_create_display(500, 500);
    ALLEGRO_EVENT_QUEUE *q = al_create_event_queue();

    ALLEGRO_TIMER *timer = al_create_timer(1/FPS);

    al_register_event_source(q, al_get_timer_event_source(timer));

    al_register_event_source(q, al_get_display_event_source(window));
    bool done = false;

    al_start_timer(timer);

    while (!done)
    {

    	ALLEGRO_EVENT e;
    	al_wait_for_event(q, &e);

    	if (e.type == ALLEGRO_EVENT_DISPLAY_CLOSE)
    	{
    		done = true;
    	}

    	if(e.type == ALLEGRO_EVENT_TIMER)
    	{
    		al_clear_to_color(al_map_rgb(255,0,0));
    		//This is an example of a primitive drawing
    		//This funtion draws a circle with filled color
    		al_draw_filled_circle(100, 100, 50, al_map_rgb(0, 0, 0));



    		//line
    		al_draw_line(200, 100, 200, 150, al_map_rgb(0,255,0), 5);

    		//rectangle (Filled and not filled)
    		al_draw_filled_rectangle(100, 200, 200, 300, al_map_rgb(255, 0 , 255));
    		al_draw_rectangle(300, 200, 400, 400, al_map_rgb(0, 255, 255), 10);

    		//Circle not filled
    		al_draw_circle(300, 300, 50, al_map_rgb(0, 0, 255), 5);

    		al_flip_display();
    	}
    }

    al_destroy_display(window);
    al_destroy_event_queue(q);
    al_destroy_timer(timer);
    return 0;
}
